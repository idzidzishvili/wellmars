<?php

          defined('BASEPATH') OR exit('No direct script access allowed');
          $lang = array();

$lang['details'] = "details";
$lang['gallery'] = "gallery";
$lang['reviews'] = "reviews";
$lang['bookThisTour'] = "bookThisTour";
$lang['yourName'] = "yourName";
$lang['whatsappViberNumber'] = "whatsappViberNumber";
$lang['orderDate'] = "orderDate";
$lang['numberOfPersons'] = "numberOfPersons";
$lang['bookNow'] = "bookNow";
$lang['contactInformation'] = "contactInformation";
$lang['phoneNumber'] = "phoneNumber";
$lang['address'] = "address";
$lang['phone'] = "phone";
$lang['sendMsg'] = "sendMsg";
$lang['forgotPassword'] = "forgotPassword";
$lang['endtDate'] = "endtDate";
$lang['recoverPassword'] = "recoverPassword";