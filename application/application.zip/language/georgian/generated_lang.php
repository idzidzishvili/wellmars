<?php

          defined('BASEPATH') OR exit('No direct script access allowed');
          $lang = array();

$lang['db_error_heading'] = "db_error_heading";
$lang['db_unable_to_connect'] = "db_unable_to_connect";
$lang['autopark'] = "autopark";